package com.example.intro_to_kotlin

/*
Hey, we add a file with a kotlin extension and link it to
the package of our project.
 */

//not sure yet, but it may have something to do with OOP
import androidx.appcompat.app.AppCompatActivity
// i guess it imports feartures of the OS so we can add it
import android.os.Bundle
// to put text in our logcat
import android.util.Log

// my class as this is OOP
class GOMD : AppCompatActivity() {
    // maybe linking with our acticity main
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //i hope i am indenting the code nicely
        // i will load some attributes as a constant val
        // this will be a string and have a consistent val
        val Artist: String = "J.Cole"
        /* another val as the year wont change and it should
        be a Int as it is a hole num
         */
        Log.d("hey",Artist)

        val YearReleased: Int = 2014
        YearReleased.toString()
        Log.d("hey1","value ="+ YearReleased)
        /*this will be a var because i don't want this to
        be a constant to
         */
        var Genre: String = "Rap"
        Log.d("hey2", Genre)
        /* ah yes this will be a double float but i will make
        it a float by adding f oh and will be a constant
         */
        val Duration: Float = 5.01f
        Duration.toString()
        Log.d("hey3", "value = " + Duration)

        // now is he good i want it to be a null value
        val Good: String? = null
        // i wont log this because how would you since its null
        // but he is good so
        val goodYes: Boolean = true
        goodYes!!.equals(Artist)
        goodYes.toString()
        Log.d("hey4", "value= " + goodYes)

        //Now current monthly listers on Spotifly
        // var it will keep changing and int
        var currentMonthlyListers: Int = 32226280
        currentMonthlyListers.toString()
        // now if you listen to him right now we will add one
        currentMonthlyListers += 1
        Log.d("hey5", "value= "+ currentMonthlyListers)

        // his age
        var age: Int = 36
        // my age
        var age1: Int = 18
        //some athermic oprations
        // age one is greate
        age > age1
        /* it is not greater so true to false or since
        maybe it actually was greater it will be true now lol not sure
         */
        //age1 !> age

        // his gender will be G so it will be char
        val gender: Char = 'G'

        /* if he has 30 in the bank and has to get the remainder
        of the divison of his tax or something
         */
        var money: Int = 30
        var tax: Int = 2
        money % tax









    }
}